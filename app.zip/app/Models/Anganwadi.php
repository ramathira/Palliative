<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Anganwadi extends Model
{
    protected $table = 'mt_anganwadi';
    protected $fillable = ['awc_name','subcentre_id'];
    public function subcentre()
    {
        return $this->belongsTo(SubCentre::class,'subcentre_id');
    }
}
