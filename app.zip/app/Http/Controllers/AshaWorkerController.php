<?php

namespace App\Http\Controllers;
use App\Models\AshaWorker;
use Illuminate\Http\Request;

class AshaWorkerController extends Controller
{
    public function index()
    {
        
        $ashas = AshaWorker::with('ward')->get(); 
        return view('pages.ashaworker.index', compact('ashas'));
    }
}
