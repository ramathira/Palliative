<?php

namespace App\Http\Controllers;
use App\Models\Anganwadi;

use Illuminate\Http\Request;

class AnganwadiController extends Controller
{
    public function index()
    {
        
        $anganwadis = Anganwadi::with('subcentre')->get(); 
        return view('pages.anganwadi.index', compact('anganwadis'));
    }

    public function show($id)
    {       
        // $ward = Anganwadi::findOrFail($id);
        // return view('pages.wards.show', compact('ward'));
    }
}
