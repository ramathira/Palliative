<?php

namespace App\Http\Controllers;
use App\Models\Ward;
use App\Models\WardMember;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;

use Illuminate\Http\Request;

class WardController extends Controller
{
    public function index()
    {
        
        $wards = Ward::with('subcentre')->get(); 
        return view('pages.wards.index', compact('wards'));
    }
    
    public function edit(Ward $ward)
    {
        $subcentres = DB::table('mt_subcentres')->get();
        return view('pages.wards.edit', compact('ward','subcentres'));
    }

     public function view_ward(): View
    {
        $wards = Ward::all(); 
        return response()->json($wards);
    }

    public function show($id)
    {       
        $ward = Ward::findOrFail($id);
        return view('pages.wards.show', compact('ward'));
    }

    public function get_ward_details($wardId)
    {
        $ward = Ward::with('wardMember')->find($wardId);


        // Return the wards as a JSON response
        return response()->json($ward);
    }


    public function members_list()
    {        
        $ward_members = WardMember::with('ward')->get(); 
        return view('pages.wards.ward_members_list', compact('ward_members'));
    }

    public function member_add()
    {
        $wards = Ward::all();
        return view('pages.wards.ward_member_add', compact('wards'));
    }
}
