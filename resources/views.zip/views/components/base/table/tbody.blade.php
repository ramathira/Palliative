<tbody>
    {{ $slot }}
</tbody>
